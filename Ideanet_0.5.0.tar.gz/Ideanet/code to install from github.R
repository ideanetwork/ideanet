
# After running this next line of code the first time,
# add hashtag at beginning of line to avoid rerunning this line
# each time and downloading a new copy. Remove the hashtag, to download
# a new copy whenever desired in case of updates and new functionality.

# install.packages("devtools") # remove hashtag to run this line of code.


library(devtools) # do not add a hashtag

# After running this next line of code the first time,
    # add hashtag at beginning of line to avoid rerunning this line
    # each time and downloading a new copy. Remove the hashtag, to download
    # a new copy whenever desired in case of updates and new functionality.

install_github("ideanetwork/ideanet") # remove hashtag to run this line of code

Ideanet::ideanet() # run the applicaton.
